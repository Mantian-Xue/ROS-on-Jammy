^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package audio_common_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.3.18 (2024-08-13)
-------------------

0.3.17 (2023-06-08)
-------------------

0.3.16 (2022-12-23)
-------------------
* Merge pull request `#202 <https://github.com/ros-drivers/audio_common/issues/202>`_ from knorth55/audio-stamped-msg
* add AudioDataStamped.msg
* Contributors: Shingo Kitagawa

0.3.15 (2022-08-29)
-------------------

0.3.14 (2022-08-18)
-------------------

0.3.13 (2022-04-07)
-------------------

0.3.12 (2021-09-01)
-------------------
* Merge branch 'master' into master
* Contributors: Shingo Kitagawa

0.3.11 (2021-04-08)
-------------------

0.3.10 (2021-01-07)
-------------------
* Change comment style in AudioInfo.msg
* [audio_common_msgs] AudioInfo.msg to add audio meta data
* Contributors: Naoya Yamaguchi

0.3.9 (2020-10-22)
------------------

0.3.8 (2020-09-13)
------------------

0.3.7 (2020-08-08)
------------------

0.3.6 (2020-05-29)
------------------
* Merge pull request `#141 <https://github.com/ros-drivers/audio_common/issues/141>`_ from knorth55/add-maintainer
  add maintainer
* add maintainer
* Contributors: Shingo Kitagawa

0.3.5 (2020-04-28)
------------------

0.3.4 (2020-04-02)
------------------
* Merge branch 'master' of github.com:ros-drivers/audio_common
* Contributors: Gerard Canal

0.3.3 (2018-05-22)
------------------

0.3.2 (2018-05-02)
------------------

0.3.1 (2016-08-28)
------------------
* Add changelogs
* Update maintainer email
* Contributors: trainman419

0.2.11 (2016-02-16)
-------------------
* Add changelogs
* Contributors: trainman419

0.2.10 (2016-01-21)
-------------------
* Add changelogs
* Contributors: trainman419

0.2.9 (2015-12-02)
------------------
* Add changelogs
* Contributors: trainman419

0.2.8 (2015-10-02)
------------------
* Update maintainer email
* Contributors: trainman419

0.2.7 (2014-07-25)
------------------

0.2.6 (2014-02-26)
------------------

0.2.5 (2014-01-23)
------------------
* "0.2.5"
* Contributors: trainman419

0.2.4 (2013-09-10)
------------------

0.2.3 (2013-07-15)
------------------

0.2.2 (2013-04-10)
------------------

0.2.1 (2013-04-08 13:59)
------------------------

0.2.0 (2013-04-08 13:49)
------------------------
* Catkinize audio_common_msgs.
* Versions and more URLs.
* Convert manifests to package.xml
* Ditch old makefiles.
* Fixed audio_msgs names to audio_common_msgs
* Renamed audio_msgs to audio_common_msgs
* Contributors: Austin Hendrix, Nate Koenig
